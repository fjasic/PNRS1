var express = require("express");
var app = express();
var bodyParser = require('body-parser');
var service = require('./service');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.urlencoded({ extended: false }))

var port = process.env.PORT || 8080;
// Create the express router object for Photos
var router = express.Router();
var mongoose   = require('mongoose');
mongoose.connect("mongodb://localhost:27017/movies");

/*get all movies*/
router.get('/movies/', service.getMovies);

/*get movie details by id*/
router.get('/movie/:id', service.getMovieDetails);

/*create movie*/
router.post('/movie', service.createMovie);

router.delete('/movie/:id', service.deleteMovie);

app.use("/api", router);
app.listen(port);
console.log('Magic happens on port ' + port);