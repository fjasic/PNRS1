var mongoose     = require('mongoose');
var Schema       = mongoose.Schema;

var MovieSchema   = new Schema({
	
    name: {
        type: String,
        required: true,
		unique: true
    },
	
	genre: {
        type: String
    },
	
	year: {
		type: String
	},
	
	duration: {
		type: String
	},
	
	director: {
		type: String
	}
	
});

module.exports = MovieSchema;