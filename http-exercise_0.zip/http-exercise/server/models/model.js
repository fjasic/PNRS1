var mongoose = require('mongoose'),
    movieSchema = require('./movie'),
    APIError = require('../APIError');

movieSchema.statics.createMovie = function(movieData, callback) {
	
    var newMessage = new model({
        name: movieData.name,
        genre: movieData.genre,
        year: movieData.year,
        duration: movieData.duration,
		director: movieData.director
    });

    newMessage.save(function(err) {
      if (err) return callback(err);
      return callback(null);
    });
};

movieSchema.statics.getAllMovies = function(callback) {
    model.find({}, function(err, found) {
        if (found.length === 0) {
            return callback(null, APIError.NO_MOVIES);
        }
        var response = [];

        found.forEach(function (object) {
            response.push({
                name: object.name,
                id: object.id
            })
        });

        return callback(response, null);
    });
};

movieSchema.statics.getMovieDetailsById = function(id, callback) {
    model.findOne({_id: id}, function(err, found) {
        if (!found) {
            return callback(null, APIError.NO_AVAILABLE_MOVIE);
        }
		return callback(found, null);
    });
};

movieSchema.statics.deleteMovie = function(id, callback) {
    model.findOneAndRemove({_id: id}, function(err, found) {
        return callback(found, err);
    });
};

var model = mongoose.model('movie', movieSchema);

module.exports = model;
