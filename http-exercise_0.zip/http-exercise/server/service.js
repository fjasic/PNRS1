var movieModel = require('./models/model'),
    APIError = require('./APIError');

exports.createMovie = function (req, res, next) {
	console.log(req.body)
	if (req.body) {
		movieModel.createMovie(req.body, function (err) {
			if (err) {
				console.log(err)
				res.status(400);
				res.send(APIError.INVALID_PARAMS);
			} else {
				res.send(APIError.OK);
			}
		});
	} else {
		res.send(APIError.NO_BODY);
	}
};

exports.getMovies = function (req, res, next) {
	console.log('Getting movies...')
	if (req.body) {
		movieModel.getAllMovies(function (resp, err) {
			if (err) {
				res.status(400);
				res.send(err);
			} else {
				res.send(resp);
			}
		});
	} else {
		res.send(APIError.NO_BODY);
	}
};

exports.getMovieDetails = function (req, res, next) {
	console.log('Getting movie details... ' + req.params.id)
	if (req.params.id) {
		movieModel.getMovieDetailsById(req.params.id, function (resp, err) {
			if (err) {
				res.status(400);
				res.send(err);
			} else {
				res.send(resp);
			}
		});
	} else {
		res.send(APIError.NO_BODY);
	}
};

exports.deleteMovie = function (req, res, next) {
    console.log('Deleting movie with id... ' + req.params.id)
	if (req.params.id) {
		movieModel.deleteMovie(req.params.id, function (resp, err) {
			if (err) {
				res.status(400);
				res.send(err);
			} else {
				res.send(resp);
			}
		});
	} else {
		res.send(APIError.NO_HEADER_PARAMS);
	}
};

