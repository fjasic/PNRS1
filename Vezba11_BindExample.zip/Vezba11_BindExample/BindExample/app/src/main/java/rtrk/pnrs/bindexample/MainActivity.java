package rtrk.pnrs.bindexample;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;

public class MainActivity extends Activity implements View.OnClickListener, ServiceConnection{

    private static final String LOG_TAG = "BindExample";

    private IBinderExample mService = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.bind).setOnClickListener(this);
        findViewById(R.id.set).setOnClickListener(this);
        findViewById(R.id.get).setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mService != null) {
            unbindService(this);
        }
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()) {
            case R.id.bind:
                Intent intent = new Intent(this, BindService.class);
                if (!bindService(intent, this, Context.BIND_AUTO_CREATE)) {
                    Log.d(LOG_TAG, "bind failed");
                }
                break;
            case R.id.set:
                try {
                    mService.setValue(33);
                } catch (NullPointerException e) {
                    Log.e(LOG_TAG, "Service not connected");
                } catch (RemoteException e) {
                    Log.e(LOG_TAG, "setValue failed", e);
                }
                break;
            case R.id.get:
                try {
                    int value = mService.getValue();
                    Log.d(LOG_TAG, "Value = " + value);
                } catch (NullPointerException e) {
                    Log.e(LOG_TAG, "Service not connected");
                } catch (RemoteException e) {
                    Log.e(LOG_TAG, "getValue failed", e);
                }
                break;
        }
    }

    @Override
    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        Log.d(LOG_TAG, "onServiceConnected");
        mService = IBinderExample.Stub.asInterface(iBinder);
        try {
            mService.setCallback(new CallbackExample());
        } catch (RemoteException e) {
            Log.e(LOG_TAG, "setCallback failed", e);
        }
    }

    @Override
    public void onServiceDisconnected(ComponentName componentName) {
        Log.d(LOG_TAG, "onServiceDisconnected");
        mService = null;
    }

    private class CallbackExample extends ICallbackExample.Stub {

        @Override
        public void onCallbackCall() throws RemoteException {
            Log.d(LOG_TAG, "onCallbackCall");
        }
    }
}
