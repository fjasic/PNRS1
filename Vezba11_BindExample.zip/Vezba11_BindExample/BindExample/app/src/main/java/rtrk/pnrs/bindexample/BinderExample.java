package rtrk.pnrs.bindexample;

import android.os.Handler;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;

public class BinderExample extends IBinderExample.Stub {

    private static final String LOG_TAG = "BinderExample";

    private int mValue = 0;
    private ICallbackExample mCallback;
    private CallbackCaller mCaller;


    @Override
    public int getValue() throws RemoteException {
        return mValue;
    }

    @Override
    public void setValue(int value) throws RemoteException {
        mValue = value;
    }

    @Override
    public void setCallback(ICallbackExample callback) {
        mCallback = callback;
        mCaller = new CallbackCaller();
        mCaller.start();
    }

    public void stop() {
        mCaller.stop();
    }

    private class CallbackCaller implements Runnable {

        private static final long PERIOD = 1000L;

        private Handler mHandler = null;
        private boolean mRun = true;

        public void start() {
            mHandler = new Handler(Looper.getMainLooper());
            mHandler.postDelayed(this, PERIOD);
        }

        public void stop() {
            mRun = false;
            mHandler.removeCallbacks(this);
        }

        @Override
        public void run() {
            if (!mRun) {
                return;
            }

            try {
                mCallback.onCallbackCall();
            } catch (NullPointerException e) {
                // callback is null, do nothing
            } catch (RemoteException e) {
                Log.e(LOG_TAG, "onCallbackCall failed", e);
            }

            mHandler.postDelayed(this, PERIOD);
        }
    }
}
