package rtrk.pnrs.bindexample;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class BindService extends Service {

    private BinderExample mBinderExample = null;

    @Override
    public IBinder onBind(Intent intent) {

        if (mBinderExample == null) {
            mBinderExample = new BinderExample();
        }
        return mBinderExample;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        mBinderExample.stop();
        return super.onUnbind(intent);
    }
}
